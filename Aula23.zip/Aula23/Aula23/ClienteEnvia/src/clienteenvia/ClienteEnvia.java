/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienteenvia;

import java.net.Socket;
import java.io.PrintStream;
import java.util.Scanner;
/**
 *
 * @author Mauricio
 */
public class ClienteEnvia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Socket cliente;
        PrintStream enviar;
        Scanner teclado = new Scanner(System.in);
        String mensagem = "Mensagem de teste do Mauricio";
        String readkey;
        
        try 
        {
            cliente = new Socket("127.0.0.1",9060);
            enviar = new PrintStream(cliente.getOutputStream());
            enviar.println(mensagem);
            readkey = teclado.nextLine();
            cliente.close();
            enviar.close();
        } catch (Exception e) {
            System.out.println("ERRO: " + e.getMessage());
        }
        
    }
    
}
