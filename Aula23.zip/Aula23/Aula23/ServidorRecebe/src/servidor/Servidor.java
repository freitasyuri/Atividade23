/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
/**
 *
 * @author Mauricio
 */
public class Servidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try
        {
            ServerSocket server = new ServerSocket(9060);
            Socket cliente = server.accept();
            
            System.out.println("Cliente conectado do IP "+cliente.getInetAddress().
                    getHostAddress());
            
            Scanner receber = new Scanner(cliente.getInputStream());
            
            while(receber.hasNextLine()){
                System.out.println(receber.nextLine());
            }

            receber.close();
            server.close();

        } catch (Exception e) {
            System.out.println("ERRO: " + e.getMessage());
        }

    }
    
}
